#include <iostream>
#include <string>
using namespace std;

// Node structure for Linked List
struct Book {
    int id;
    string title;
    string author;
    Book* next;
};

// Class for Library Management
class Library {
private:
    Book* head;  // Head pointer for linked list

public:
    // Constructor
    Library() {
        head = nullptr;
    }

    // Function to add a new book
    void addBook(int id, string title, string author) {
        Book* newBook = new Book;
        newBook->id = id;
        newBook->title = title;
        newBook->author = author;
        newBook->next = nullptr;

        // If list is empty
        if (head == nullptr) {
            head = newBook;
            cout << "\nBook added successfully!\n";
            return;
        }

        // Check for duplicate ID
        Book* temp = head;
        while (temp != nullptr) {
            if (temp->id == id) {
                cout << "\nBook with ID " << id << " already exists!\n";
                delete newBook;
                return;
            }
            temp = temp->next;
        }

        // Insert at end
        temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newBook;
        cout << "\nBook added successfully!\n";
    }

    // Function to delete a book by ID
    void deleteBook(int id) {
        if (head == nullptr) {
            cout << "\nLibrary is empty! No books to delete.\n";
            return;
        }

        Book* temp = head;
        Book* prev = nullptr;

        // If book to delete is first node
        if (temp != nullptr && temp->id == id) {
            head = temp->next;
            delete temp;
            cout << "\nBook deleted successfully!\n";
            return;
        }

        // Search for book to delete
        while (temp != nullptr && temp->id != id) {
            prev = temp;
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "\nBook not found!\n";
            return;
        }

        prev->next = temp->next;
        delete temp;
        cout << "\nBook deleted successfully!\n";
    }

    // Function to search for a book by ID
    void searchBook(int id) {
        Book* temp = head;
        while (temp != nullptr) {
            if (temp->id == id) {
                cout << "\nBook Found:\n";
                cout << "ID: " << temp->id << endl;
                cout << "Title: " << temp->title << endl;
                cout << "Author: " << temp->author << endl;
                return;
            }
            temp = temp->next;
        }
        cout << "\nBook not found!\n";
    }

    // Function to display all books
    void displayBooks() {
        if (head == nullptr) {
            cout << "\nNo books available in the library.\n";
            return;
        }

        cout << "\n--- Library Books ---\n";
        Book* temp = head;
        while (temp != nullptr) {
            cout << "ID: " << temp->id << endl;
            cout << "Title: " << temp->title << endl;
            cout << "Author: " << temp->author << endl;
            cout << "----------------------\n";
            temp = temp->next;
        }
    }

    // Destructor to free memory
    ~Library() {
        Book* current = head;
        while (current != nullptr) {
            Book* next = current->next;
            delete current;
            current = next;
        }
    }
};

// Main Menu
int main() {
    Library lib;
    int choice, id;
    string title, author;

    do {
        cout << "\n==== Library Management System (Using Linked List) ====\n";
        cout << "1. Add Book\n";
        cout << "2. Delete Book\n";
        cout << "3. Search Book\n";
        cout << "4. Display All Books\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore(); // to clear input buffer

        switch (choice) {
        case 1:
            cout << "\nEnter Book ID: ";
            cin >> id;
            cin.ignore();
            cout << "Enter Book Title: ";
            getline(cin, title);
            cout << "Enter Author Name: ";
            getline(cin, author);
            lib.addBook(id, title, author);
            break;

        case 2:
            cout << "\nEnter Book ID to delete: ";
            cin >> id;
            lib.deleteBook(id);
            break;

        case 3:
            cout << "\nEnter Book ID to search: ";
            cin >> id;
            lib.searchBook(id);
            break;

        case 4:
            lib.displayBooks();
            break;

        case 5:
            cout << "\nExiting program... Goodbye!\n";
            break;

        default:
            cout << "\nInvalid choice! Please try again.\n";
        }
    } while (choice != 5);

    return 0;
}
